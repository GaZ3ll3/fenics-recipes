from misc.test import *
from symbolics.test import *
from evaluate_basis.test import *

if __name__ == "__main__":
    unittest.main()
